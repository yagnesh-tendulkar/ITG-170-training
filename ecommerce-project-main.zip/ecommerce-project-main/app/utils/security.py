from passlib.context import CryptContext
from datetime import datetime, timedelta
import jwt

# =========================
# JWT CONFIG
# =========================
SECRET_KEY = "your-secret-key-change-this"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

# =========================
# PASSWORD HASHING SETUP
# =========================
pwd_context = CryptContext(
    schemes=["bcrypt"],
    deprecated="auto"
)

# =========================
# PASSWORD HASH FUNCTION
# =========================
def hash_password(password: str):
    password = password[:72]  # bcrypt limit fix
    return pwd_context.hash(password)


# =========================
# VERIFY PASSWORD
# =========================
def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    Verify hashed password
    """
    if len(plain_password.encode("utf-8")) > 72:
        plain_password = plain_password.encode("utf-8")[:72].decode("utf-8", "ignore")

    return pwd_context.verify(plain_password, hashed_password)


# =========================
# CREATE JWT TOKEN
# =========================
def create_access_token(data: dict, expires_delta: int = ACCESS_TOKEN_EXPIRE_MINUTES):
    """
    Generate JWT token
    """
    to_encode = data.copy()

    expire = datetime.utcnow() + timedelta(minutes=expires_delta)
    to_encode.update({"exp": expire})

    token = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return token