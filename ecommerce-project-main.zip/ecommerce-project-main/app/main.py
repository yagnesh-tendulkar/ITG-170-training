from fastapi import FastAPI
from app.routes import auth, user, task, upload, stream, health, metrics
from app.middleware.logging_middleware import LoggingMiddleware
from app.middleware.request_id_middleware import RequestIDMiddleware
from app.exceptions.handlers import register_exception_handlers
from app.routes import auth



app = FastAPI(
    title="Smart Task & File Processing API",
    version="1.0.0"
)

# ---------------- MIDDLEWARE ----------------
app.add_middleware(LoggingMiddleware)
app.add_middleware(RequestIDMiddleware)

# ---------------- ROUTES ----------------
app.include_router(auth.router, prefix="/auth", tags=["Auth"])
app.include_router(user.router, prefix="/users", tags=["Users"])
app.include_router(task.router, prefix="/tasks", tags=["Tasks"])
app.include_router(upload.router, prefix="/upload", tags=["Upload"])
app.include_router(stream.router, prefix="/stream", tags=["Streaming"])
app.include_router(health.router, prefix="/health", tags=["Health"])
app.include_router(auth.router, prefix="/auth")
app.include_router(metrics.router, prefix="/metrics", tags=["Metrics"])

# ---------------- EXCEPTIONS ----------------
register_exception_handlers(app)


@app.get("/")
def root():
    return {
        "message": "Smart Task & File Processing API is running"
    }