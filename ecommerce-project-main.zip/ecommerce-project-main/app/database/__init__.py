from app.database.database import Base, engine
from app.models import user, task, complaint

Base.metadata.create_all(bind=engine)

print("Database tables created successfully!")