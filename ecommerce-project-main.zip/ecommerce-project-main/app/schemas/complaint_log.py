from pydantic import BaseModel

class ComplaintLogResponse(BaseModel):

    complaint_id: int

    action: str

    status: str