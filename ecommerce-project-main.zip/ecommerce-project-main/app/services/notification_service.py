def send_email():

    print(
        "Complaint notification sent"
    )