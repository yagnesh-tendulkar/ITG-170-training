from models.complaint import Complaint

def create_complaint(
    db,
    complaint_data
):

    complaint = Complaint(
        title=complaint_data.title,
        description=complaint_data.description
    )

    db.add(complaint)

    db.commit()

    db.refresh(complaint)

    return complaint