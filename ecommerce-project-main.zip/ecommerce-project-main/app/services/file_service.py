import os

UPLOAD_DIR = "uploads"

os.makedirs(UPLOAD_DIR, exist_ok=True)

ALLOWED_TYPES = ["image/png", "image/jpeg", "application/pdf"]
MAX_SIZE = 5 * 1024 * 1024  # 5MB

def validate_file(file):
    if file.content_type not in ALLOWED_TYPES:
        return False, "Invalid file type"

    return True, "OK"


def save_file(file):
    file_path = os.path.join(UPLOAD_DIR, file.filename)

    with open(file_path, "wb") as f:
        f.write(file.file.read())

    return file_path