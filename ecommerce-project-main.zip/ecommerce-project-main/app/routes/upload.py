from fastapi import APIRouter, UploadFile, File, HTTPException
import os

router = APIRouter(tags=["File Upload"])

UPLOAD_DIR = "app/uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Allowed file types
ALLOWED_TYPES = [
    "application/pdf",
    "image/png",
    "image/jpeg",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
]

# 5 MB limit
MAX_FILE_SIZE = 5 * 1024 * 1024

@router.post("/tasks/{task_id}/upload")
async def upload_file(task_id: int, file: UploadFile = File(...)):

    # MIME Type Validation
    if file.content_type not in ALLOWED_TYPES:
        raise HTTPException(
            status_code=400,
            detail="Only PDF, PNG, JPG, JPEG and DOCX files are allowed"
        )

    content = await file.read()

    # File Size Validation
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=400,
            detail="File size should not exceed 5 MB"
        )

    # Duplicate Check
    file_path = os.path.join(UPLOAD_DIR, file.filename)

    if os.path.exists(file_path):
        raise HTTPException(
            status_code=400,
            detail="File already exists"
        )

    with open(file_path, "wb") as f:
        f.write(content)

    return {
        "task_id": task_id,
        "filename": file.filename,
        "size_kb": round(len(content) / 1024, 2),
        "message": "File uploaded successfully"
    }