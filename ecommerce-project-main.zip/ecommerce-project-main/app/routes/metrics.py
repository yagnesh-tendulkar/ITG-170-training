from fastapi import APIRouter

router = APIRouter(
    tags=["Metrics"]
)

@router.get("/metrics")
def metrics():

    return {

        "total_users": 100,

        "total_complaints": 250,

        "resolved": 180,

        "pending": 70
    }